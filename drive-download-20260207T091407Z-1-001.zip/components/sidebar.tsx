"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Clock, Lock, Sparkles, Settings, LogOut, IndianRupee } from "lucide-react"
import { cn } from "@/lib/utils"
import { useFinancialData } from "@/lib/financial-context"
import { useState } from "react"

function formatINR(val: number) {
  if (val >= 100000) return `${(val / 100000).toFixed(1)}L`
  if (val >= 1000) return `${(val / 1000).toFixed(0)}K`
  return val.toString()
}

const navItems = [
  { label: "Home", href: "/dashboard", icon: Home },
  { label: "Time Travel", href: "/dashboard/time-travel", icon: Clock },
  { label: "Vault", href: "/dashboard/vault", icon: Lock },
  { label: "Oracle", href: "/dashboard/oracle", icon: Sparkles },
  { label: "Settings", href: "/dashboard/settings", icon: Settings },
]

export function Sidebar() {
  const pathname = usePathname()
  const { data, setData } = useFinancialData()
  const [showAdjuster, setShowAdjuster] = useState(false)

  return (
    <aside
      className="fixed left-0 top-0 z-40 flex h-screen w-[72px] flex-col items-center border-r border-white/5 bg-[rgba(5,5,5,0.9)] py-6"
      style={{ backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)" }}
    >
      {/* Logo */}
      <Link href="/dashboard" className="mb-10 flex flex-col items-center gap-1.5">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#00f2ea]/10 ring-1 ring-[#00f2ea]/20">
          <span className="text-sm font-semibold text-[#00f2ea]">CX</span>
        </div>
      </Link>

      {/* Navigation */}
      <nav className="flex flex-1 flex-col items-center gap-2">
        {navItems.map((item) => {
          const isActive =
            item.href === "/dashboard"
              ? pathname === "/dashboard"
              : pathname.startsWith(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "group relative flex h-11 w-11 items-center justify-center rounded-xl transition-all duration-200",
                isActive
                  ? "sidebar-active-glow bg-white/5 text-[#00f2ea]"
                  : "text-white/35 hover:bg-white/[0.03] hover:text-white/60"
              )}
              aria-label={item.label}
            >
              <item.icon className="h-[18px] w-[18px]" strokeWidth={1.5} />
              <span className="pointer-events-none absolute left-full ml-3 whitespace-nowrap rounded-md bg-[#111] px-2.5 py-1 text-[10px] uppercase tracking-[0.12em] text-white/70 opacity-0 shadow-lg ring-1 ring-white/10 transition-opacity group-hover:opacity-100">
                {item.label}
              </span>
            </Link>
          )
        })}

        {/* Income Adjuster Toggle */}
        <button
          type="button"
          onClick={() => setShowAdjuster(!showAdjuster)}
          className={cn(
            "group relative mt-4 flex h-11 w-11 items-center justify-center rounded-xl transition-all duration-200",
            showAdjuster
              ? "bg-[#00f2ea]/10 text-[#00f2ea]"
              : "text-white/35 hover:bg-white/[0.03] hover:text-white/60"
          )}
          aria-label="Adjust Income"
        >
          <IndianRupee className="h-[18px] w-[18px]" strokeWidth={1.5} />
          <span className="pointer-events-none absolute left-full ml-3 whitespace-nowrap rounded-md bg-[#111] px-2.5 py-1 text-[10px] uppercase tracking-[0.12em] text-white/70 opacity-0 shadow-lg ring-1 ring-white/10 transition-opacity group-hover:opacity-100">
            Adjust
          </span>
        </button>
      </nav>

      {/* Income Adjuster Panel (slides out) */}
      {showAdjuster && (
        <div
          className="absolute left-[72px] bottom-24 z-50 w-64 rounded-xl border border-white/[0.08] bg-[#0a0a0a]/95 p-5 shadow-2xl"
          style={{ backdropFilter: "blur(40px)", WebkitBackdropFilter: "blur(40px)" }}
        >
          <h4 className="heading-luxury mb-4 text-[10px] uppercase tracking-[0.15em] text-white/40">
            Quick Adjust
          </h4>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-white/30">Income</span>
                <span className="mono-num text-xs text-[#00f2ea]">
                  {"\u20B9"}{formatINR(data.monthlyIncome)}
                </span>
              </div>
              <input
                type="range"
                min={10000}
                max={1000000}
                step={5000}
                value={data.monthlyIncome}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, monthlyIncome: Number(e.target.value) }))
                }
                className="luxury-slider w-full"
              />
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-white/30">Expenses</span>
                <span className="mono-num text-xs text-[#ff0055]">
                  {"\u20B9"}{formatINR(data.monthlyExpenses)}
                </span>
              </div>
              <input
                type="range"
                min={5000}
                max={500000}
                step={5000}
                value={data.monthlyExpenses}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, monthlyExpenses: Number(e.target.value) }))
                }
                className="luxury-slider w-full"
              />
            </div>
            <div className="h-px bg-white/[0.04]" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wider text-white/25">Savings</span>
              <span className="mono-num text-sm text-[#00f2ea]">
                {"\u20B9"}{formatINR(Math.max(0, data.monthlyIncome - data.monthlyExpenses))}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Sign Out */}
      <Link
        href="/"
        className="flex h-11 w-11 items-center justify-center rounded-xl text-white/25 transition-colors hover:bg-white/[0.03] hover:text-white/50"
        aria-label="Sign Out"
      >
        <LogOut className="h-[18px] w-[18px]" strokeWidth={1.5} />
      </Link>
    </aside>
  )
}
