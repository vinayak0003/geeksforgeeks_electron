"use client"

import React, { useRef, useCallback, useState, useMemo } from "react"
import { Landmark, Coins, BarChart3 } from "lucide-react"
import { useFinancialData } from "@/lib/financial-context"
import { motion } from "framer-motion"

interface TiltCardProps {
  children: React.ReactNode
  accentColor: string
}

function TiltCard({ children, accentColor }: TiltCardProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [transform, setTransform] = useState("perspective(800px) rotateX(0deg) rotateY(0deg)")

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width
    const y = (e.clientY - rect.top) / rect.height
    const rotateX = (0.5 - y) * 12
    const rotateY = (x - 0.5) * 12
    setTransform(`perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`)
  }, [])

  const handleMouseLeave = useCallback(() => {
    setTransform("perspective(800px) rotateX(0deg) rotateY(0deg)")
  }, [])

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, filter: "blur(10px)" }}
      whileInView={{ opacity: 1, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.6 }}
      className="glass-highlight glass-spotlight relative overflow-hidden rounded-xl border border-white/[0.08] bg-white/[0.03] p-5 transition-transform duration-200"
      style={{
        backdropFilter: "blur(40px)",
        WebkitBackdropFilter: "blur(40px)",
        transform,
        transformStyle: "preserve-3d",
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          background: `linear-gradient(135deg, transparent 30%, ${accentColor}40 50%, transparent 70%)`,
        }}
      />
      <div className="relative z-[2]">{children}</div>
    </motion.div>
  )
}

function formatINR(val: number) {
  if (val >= 100000) return `${(val / 100000).toFixed(1)}L`
  if (val >= 1000) return `${(val / 1000).toFixed(0)}K`
  return val.toFixed(0)
}

export function KnowledgeVault() {
  const { data } = useFinancialData()
  const [taxRegime, setTaxRegime] = useState<"old" | "new">("new")

  const taxCalc = useMemo(() => {
    const annual = data.monthlyIncome * 12
    // Simplified Indian tax calculation
    const oldTax =
      annual <= 250000
        ? 0
        : annual <= 500000
          ? (annual - 250000) * 0.05
          : annual <= 1000000
            ? 12500 + (annual - 500000) * 0.2
            : 112500 + (annual - 1000000) * 0.3
    const newTax =
      annual <= 300000
        ? 0
        : annual <= 700000
          ? (annual - 300000) * 0.05
          : annual <= 1000000
            ? 20000 + (annual - 700000) * 0.1
            : annual <= 1200000
              ? 50000 + (annual - 1000000) * 0.15
              : annual <= 1500000
                ? 80000 + (annual - 1200000) * 0.2
                : 140000 + (annual - 1500000) * 0.3

    const oldRate = annual > 0 ? ((oldTax / annual) * 100).toFixed(1) : "0"
    const newRate = annual > 0 ? ((newTax / annual) * 100).toFixed(1) : "0"
    const saving = Math.abs(oldTax - newTax)
    return { oldTax, newTax, oldRate, newRate, saving }
  }, [data.monthlyIncome])

  return (
    <div className="flex flex-col gap-4">
      <h3 className="heading-luxury text-xs uppercase tracking-[0.15em] text-white/40">
        Indian Knowledge Vault
      </h3>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {/* Tax Engine Card */}
        <TiltCard accentColor="#00f2ea">
          <div className="flex items-start justify-between">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#00f2ea]/10">
              <Landmark className="h-4 w-4 text-[#00f2ea]" strokeWidth={1.5} />
            </div>
            <motion.span
              key={`save-${taxCalc.saving}`}
              initial={{ scale: 1.2, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="rounded-full bg-[#00f2ea]/10 px-2.5 py-0.5 text-[10px] text-[#00f2ea] ring-1 ring-[#00f2ea]/20"
            >
              Save {"\u20B9"}{formatINR(taxCalc.saving)}
            </motion.span>
          </div>
          <h4 className="mt-4 text-sm text-white/80">Tax Engine</h4>
          <p className="mt-1 text-[11px] text-white/30">
            Based on {"\u20B9"}{formatINR(data.monthlyIncome * 12)} annual income
          </p>

          {/* Toggle */}
          <div className="mt-4 flex items-center gap-3">
            <button
              type="button"
              onClick={() => setTaxRegime("old")}
              className={`rounded-md px-3 py-1.5 text-[10px] uppercase tracking-[0.1em] transition-all ${
                taxRegime === "old"
                  ? "bg-[#00f2ea]/15 text-[#00f2ea] ring-1 ring-[#00f2ea]/30"
                  : "bg-white/[0.03] text-white/30 hover:text-white/50"
              }`}
            >
              Old Regime
            </button>
            <button
              type="button"
              onClick={() => setTaxRegime("new")}
              className={`rounded-md px-3 py-1.5 text-[10px] uppercase tracking-[0.1em] transition-all ${
                taxRegime === "new"
                  ? "bg-[#00f2ea]/15 text-[#00f2ea] ring-1 ring-[#00f2ea]/30"
                  : "bg-white/[0.03] text-white/30 hover:text-white/50"
              }`}
            >
              New Regime
            </button>
          </div>
          <div className="mt-3 flex flex-col gap-1">
            <p className="mono-num text-xs text-white/50">
              Tax:{" "}
              <motion.span
                key={`tax-${taxRegime}`}
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-[#00f2ea]"
              >
                {"\u20B9"}{formatINR(taxRegime === "new" ? taxCalc.newTax : taxCalc.oldTax)}
              </motion.span>
            </p>
            <p className="mono-num text-xs text-white/50">
              Effective Rate:{" "}
              <span className="text-[#00f2ea]">
                {taxRegime === "new" ? taxCalc.newRate : taxCalc.oldRate}%
              </span>
            </p>
          </div>
        </TiltCard>

        {/* Gold Card */}
        <TiltCard accentColor="#eab308">
          <div className="flex items-start justify-between">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-yellow-500/10">
              <Coins className="h-4 w-4 text-yellow-500" strokeWidth={1.5} />
            </div>
            <span className="rounded-full bg-yellow-500/10 px-2.5 py-0.5 text-[10px] text-yellow-500 ring-1 ring-yellow-500/20">
              2.5% Interest
            </span>
          </div>
          <h4 className="mt-4 text-sm text-white/80">Gold Insight</h4>
          <p className="mt-1 text-[11px] text-white/30">SGB vs Physical Gold</p>

          <div className="mt-4 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Sovereign Gold Bond</span>
              <span className="mono-num text-xs text-yellow-500">{"\u20B9"}6,240/g</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Physical 24K</span>
              <span className="mono-num text-xs text-white/50">{"\u20B9"}6,380/g</span>
            </div>
            <div className="mt-1 h-px bg-white/5" />
            <p className="text-[10px] text-white/25">
              SGB earns 2.5% p.a. + zero making charges
            </p>
          </div>
        </TiltCard>

        {/* Market Card */}
        <TiltCard accentColor="#ff0055">
          <div className="flex items-start justify-between">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#ff0055]/10">
              <BarChart3 className="h-4 w-4 text-[#ff0055]" strokeWidth={1.5} />
            </div>
            <div className="flex h-2 w-2 animate-pulse rounded-full bg-[#00f2ea]" />
          </div>
          <h4 className="mt-4 text-sm text-white/80">Market Pulse</h4>
          <p className="mt-1 text-[11px] text-white/30">Live indices & indicators</p>

          <div className="mt-4 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Nifty 50</span>
              <span className="mono-num text-xs text-[#00f2ea]">24,500</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Sensex</span>
              <span className="mono-num text-xs text-[#00f2ea]">80,240</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Inflation</span>
              <span className="mono-num text-xs text-[#ff0055]">5.6%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-white/35">Repo Rate</span>
              <span className="mono-num text-xs text-white/50">6.5%</span>
            </div>
          </div>
        </TiltCard>
      </div>
    </div>
  )
}
