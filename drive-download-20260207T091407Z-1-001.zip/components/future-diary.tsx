"use client"

import React from "react"
import { GlassCard } from "@/components/glass-card"
import {
  Car,
  Heart,
  Plane,
  Rocket,
  TrendingDown,
  GraduationCap,
  Home as HomeIcon,
} from "lucide-react"
import { motion } from "framer-motion"

interface TimelineItem {
  year: string
  label: string
  amount: string
  type: "expense" | "milestone" | "loss"
  icon: React.ElementType
}

const timelineItems: TimelineItem[] = [
  { year: "2026", label: "Bought First Car", amount: "-\u20B98L", type: "expense", icon: Car },
  {
    year: "2028",
    label: "Dream Home Down Payment",
    amount: "-\u20B930L",
    type: "expense",
    icon: HomeIcon,
  },
  { year: "2030", label: "Wedding Expense", amount: "-\u20B925L", type: "loss", icon: Heart },
  {
    year: "2032",
    label: "Child Education Fund",
    amount: "-\u20B915L",
    type: "expense",
    icon: GraduationCap,
  },
  { year: "2035", label: "World Tour", amount: "-\u20B95L", type: "expense", icon: Plane },
  {
    year: "2038",
    label: "Market Correction",
    amount: "-12%",
    type: "loss",
    icon: TrendingDown,
  },
  {
    year: "2045",
    label: "Crossed \u20B95 Crores",
    amount: "+\u20B95Cr",
    type: "milestone",
    icon: Rocket,
  },
]

function TimelineEntry({ item, index }: { item: TimelineItem; index: number }) {
  const color =
    item.type === "milestone"
      ? "#00f2ea"
      : item.type === "loss"
        ? "#ff0055"
        : "rgba(255,255,255,0.4)"

  const Icon = item.icon

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, filter: "blur(10px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.5, delay: index * 0.06 }}
      className="relative flex gap-4 pb-6 last:pb-0"
    >
      <div className="flex flex-col items-center">
        <div
          className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full border"
          style={{
            borderColor: `${color}40`,
            backgroundColor: `${color}10`,
          }}
        >
          <Icon className="h-3.5 w-3.5" style={{ color }} strokeWidth={1.5} />
        </div>
        {index < timelineItems.length - 1 && (
          <div className="mt-1 w-px flex-1 bg-gradient-to-b from-white/[0.08] to-transparent" />
        )}
      </div>

      <div className="flex flex-1 flex-col gap-0.5 pt-1">
        <span className="mono-num text-[10px] uppercase tracking-[0.12em] text-white/30">
          {item.year}
        </span>
        <span className="text-sm text-white/80">{item.label}</span>
        <span className="mono-num text-xs" style={{ color }}>
          {item.amount}
        </span>
      </div>
    </motion.div>
  )
}

export function FutureDiary() {
  return (
    <GlassCard className="flex h-full flex-col">
      <h3 className="heading-luxury mb-5 text-xs uppercase tracking-[0.15em] text-white/40">
        Future Diary
      </h3>
      <div className="flex-1 overflow-y-auto pr-1">
        {timelineItems.map((item, i) => (
          <TimelineEntry key={item.year} item={item} index={i} />
        ))}
      </div>
    </GlassCard>
  )
}
