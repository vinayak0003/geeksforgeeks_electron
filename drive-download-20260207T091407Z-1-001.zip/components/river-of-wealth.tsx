"use client"

import React, { useMemo, useState, useCallback, useRef, useEffect } from "react"
import { GlassCard } from "@/components/glass-card"
import { useFinancialData } from "@/lib/financial-context"
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"

const years = Array.from({ length: 27 }, (_, i) => 2024 + i)

function formatCurrency(val: number) {
  if (val >= 10000000) return `${(val / 10000000).toFixed(1)} Cr`
  if (val >= 100000) return `${(val / 100000).toFixed(1)} L`
  if (val >= 1000) return `${(val / 1000).toFixed(0)}K`
  return val.toFixed(0)
}

interface EventNode {
  id: string
  label: string
  yearIndex: number
  cost: number
  color: string
}

const initialEvents: EventNode[] = [
  { id: "car", label: "Car", yearIndex: 2, cost: 800000, color: "#00f2ea" },
  { id: "wedding", label: "Wedding", yearIndex: 6, cost: 2500000, color: "#ff0055" },
  { id: "travel", label: "Travel", yearIndex: 11, cost: 500000, color: "#3b82ff" },
]

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; dataKey: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div
      className="rounded-lg border border-white/10 bg-[#0a0a0a]/95 px-3 py-2 text-xs shadow-xl"
      style={{ backdropFilter: "blur(20px)" }}
    >
      <p className="mb-1 text-white/50">{label}</p>
      {payload.map((entry) => (
        <p key={entry.dataKey} className="mono-num text-white/90">
          {"\u20B9"}
          {formatCurrency(entry.value)}
        </p>
      ))}
    </div>
  )
}

function MagnifiedDot(props: Record<string, unknown>) {
  const { cx, cy, index } = props as { cx: number; cy: number; index: number }
  if (typeof cx !== "number" || typeof cy !== "number") return null
  // Show dots every 3 years for clarity
  if (index % 3 !== 0) return null
  return (
    <circle
      cx={cx}
      cy={cy}
      r={4}
      fill="#00f2ea"
      stroke="#050505"
      strokeWidth={2}
      className="transition-all duration-200 hover:r-[8]"
      style={{ filter: "drop-shadow(0 0 4px rgba(0,242,234,0.5))" }}
    />
  )
}

export function RiverOfWealth() {
  const { data } = useFinancialData()
  const [events] = useState(initialEvents)
  const [hoveredEvent, setHoveredEvent] = useState<string | null>(null)
  const [nodePositions, setNodePositions] = useState<Record<string, { x: number; y: number }>>({})
  const containerRef = useRef<HTMLDivElement>(null)
  const [dragId, setDragId] = useState<string | null>(null)

  // Generate wealth projection from user inputs
  const wealthData = useMemo(() => {
    const income = data.monthlyIncome
    const expenses = data.monthlyExpenses
    let wealth = data.currentInvestments

    return years.map((year) => {
      const prevWealth = wealth
      wealth = prevWealth + (income - expenses) * 12 * 1.1
      if (wealth < 0) wealth = 0
      return { year: year.toString(), projected: Math.round(wealth) }
    })
  }, [data.monthlyIncome, data.monthlyExpenses, data.currentInvestments])

  const maxVal = useMemo(
    () => Math.max(...wealthData.map((d) => d.projected), 100000),
    [wealthData]
  )

  // Compute event node positions based on chart
  useEffect(() => {
    if (!containerRef.current) return
    const rect = containerRef.current.getBoundingClientRect()
    const positions: Record<string, { x: number; y: number }> = {}
    for (const ev of events) {
      const idx = ev.yearIndex
      if (idx < 0 || idx >= wealthData.length) continue
      const xRatio = idx / (wealthData.length - 1)
      const yRatio = 1 - wealthData[idx].projected / maxVal
      positions[ev.id] = {
        x: 60 + xRatio * (rect.width - 90),
        y: 20 + yRatio * (rect.height - 50),
      }
    }
    setNodePositions(positions)
  }, [events, wealthData, maxVal])

  const handleMouseDown = useCallback(
    (e: React.MouseEvent, id: string) => {
      e.preventDefault()
      setDragId(id)
    },
    []
  )

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!dragId || !containerRef.current) return
      const rect = containerRef.current.getBoundingClientRect()
      setNodePositions((prev) => ({
        ...prev,
        [dragId]: {
          x: Math.max(20, Math.min(rect.width - 20, e.clientX - rect.left)),
          y: Math.max(10, Math.min(rect.height - 30, e.clientY - rect.top)),
        },
      }))
    },
    [dragId]
  )

  const handleMouseUp = useCallback(() => {
    setDragId(null)
  }, [])

  return (
    <GlassCard className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="heading-luxury text-xs uppercase tracking-[0.15em] text-white/40">
            River of Wealth
          </h3>
          <p className="mt-1 text-[11px] text-white/25">
            Projected from your inputs. Drag event nodes to simulate.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="mono-num text-xs text-white/30">
            Savings: {"\u20B9"}{formatCurrency(Math.max(0, data.monthlyIncome - data.monthlyExpenses))}/mo
          </span>
        </div>
      </div>

      <div
        ref={containerRef}
        className="relative h-[320px] w-full select-none"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={wealthData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="cyanGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00f2ea" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#00f2ea" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
            <XAxis
              dataKey="year"
              tick={{ fontSize: 10, fill: "rgba(255,255,255,0.25)" }}
              axisLine={false}
              tickLine={false}
              interval={4}
            />
            <YAxis
              tickFormatter={(val) => `\u20B9${formatCurrency(val)}`}
              tick={{ fontSize: 10, fill: "rgba(255,255,255,0.25)" }}
              axisLine={false}
              tickLine={false}
              width={70}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="projected"
              stroke="#00f2ea"
              strokeWidth={2}
              fill="url(#cyanGrad)"
              dot={<MagnifiedDot />}
              activeDot={{
                r: 8,
                fill: "#00f2ea",
                stroke: "#050505",
                strokeWidth: 3,
                style: { filter: "drop-shadow(0 0 10px rgba(0,242,234,0.7))" },
              }}
              animationDuration={800}
              style={{ filter: "drop-shadow(0 0 6px rgba(0,242,234,0.4))" }}
            />
          </AreaChart>
        </ResponsiveContainer>

        {/* Draggable Event Nodes */}
        {events.map((ev) => {
          const pos = nodePositions[ev.id]
          if (!pos) return null
          return (
            <div
              key={ev.id}
              className="absolute z-10"
              style={{
                left: pos.x - 14,
                top: pos.y - 14,
                cursor: dragId === ev.id ? "grabbing" : "grab",
              }}
              onMouseDown={(e) => handleMouseDown(e, ev.id)}
              onMouseEnter={() => setHoveredEvent(ev.id)}
              onMouseLeave={() => setHoveredEvent(null)}
            >
              <div
                className="flex h-7 w-7 items-center justify-center rounded-full border-2 transition-transform hover:scale-125"
                style={{
                  borderColor: ev.color,
                  backgroundColor: `${ev.color}15`,
                  boxShadow: `0 0 12px ${ev.color}40`,
                }}
              >
                <div className="h-2 w-2 rounded-full" style={{ backgroundColor: ev.color }} />
              </div>

              <span
                className="absolute left-1/2 top-full mt-1.5 -translate-x-1/2 whitespace-nowrap text-[9px] uppercase tracking-[0.1em]"
                style={{ color: ev.color }}
              >
                {ev.label}
              </span>

              {hoveredEvent === ev.id && (
                <div
                  className="absolute bottom-full left-1/2 mb-3 -translate-x-1/2 whitespace-nowrap rounded-lg border border-white/10 bg-[#0a0a0a]/95 px-3 py-2 shadow-2xl"
                  style={{ backdropFilter: "blur(20px)" }}
                >
                  <p className="text-[10px] uppercase tracking-wider text-white/40">
                    {years[ev.yearIndex]}
                  </p>
                  <p className="mono-num mt-0.5 text-sm text-white/90">
                    Cost: {"\u20B9"}{formatCurrency(ev.cost)}
                  </p>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </GlassCard>
  )
}
