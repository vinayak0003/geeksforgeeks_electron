"use client"

import { cn } from "@/lib/utils"
import type { ReactNode, MouseEvent } from "react"
import { useRef, useCallback } from "react"

interface GlassCardProps {
  children: ReactNode
  className?: string
  spotlight?: boolean
}

export function GlassCard({ children, className, spotlight = true }: GlassCardProps) {
  const ref = useRef<HTMLDivElement>(null)

  const handleMouseMove = useCallback((e: MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    ref.current.style.setProperty("--spotlight-x", `${e.clientX - rect.left}px`)
    ref.current.style.setProperty("--spotlight-y", `${e.clientY - rect.top}px`)
  }, [])

  return (
    <div
      ref={ref}
      onMouseMove={spotlight ? handleMouseMove : undefined}
      className={cn(
        "glass-highlight relative rounded-xl border border-white/[0.08] bg-white/[0.03] p-6",
        spotlight && "glass-spotlight",
        className
      )}
      style={{ backdropFilter: "blur(40px)", WebkitBackdropFilter: "blur(40px)" }}
    >
      <div className="relative z-[2]">{children}</div>
    </div>
  )
}
