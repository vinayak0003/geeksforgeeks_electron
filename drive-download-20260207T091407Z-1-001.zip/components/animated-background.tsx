"use client"

export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {/* Cyan orb */}
      <div
        className="absolute w-[700px] h-[700px] rounded-full opacity-[0.04]"
        style={{
          background: "radial-gradient(circle, #00f2ea 0%, transparent 70%)",
          top: "5%",
          left: "10%",
          animation: "float-cyan 28s ease-in-out infinite",
        }}
      />
      {/* Magenta orb */}
      <div
        className="absolute w-[550px] h-[550px] rounded-full opacity-[0.03]"
        style={{
          background: "radial-gradient(circle, #ff0055 0%, transparent 70%)",
          top: "45%",
          right: "5%",
          animation: "float-magenta 32s ease-in-out infinite",
        }}
      />
      {/* Blue orb */}
      <div
        className="absolute w-[480px] h-[480px] rounded-full opacity-[0.03]"
        style={{
          background: "radial-gradient(circle, #3b82ff 0%, transparent 70%)",
          bottom: "8%",
          left: "35%",
          animation: "float-blue 26s ease-in-out infinite",
        }}
      />
    </div>
  )
}
