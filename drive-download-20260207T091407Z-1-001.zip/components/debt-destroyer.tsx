"use client"

import { GlassCard } from "@/components/glass-card"
import { Flame } from "lucide-react"

export function DebtDestroyer() {
  const totalDebt = 2400000
  const paidOff = 1560000
  const progress = (paidOff / totalDebt) * 100

  return (
    <GlassCard className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#ff0055]/10">
            <Flame className="h-4 w-4 text-[#ff0055]" strokeWidth={1.5} />
          </div>
          <h3 className="heading-luxury text-xs uppercase tracking-[0.15em] text-white/40">
            Debt Destroyer
          </h3>
        </div>
        <span className="mono-num text-xs text-white/30">
          {"\u20B9"}{(paidOff / 100000).toFixed(1)}L / {"\u20B9"}{(totalDebt / 100000).toFixed(1)}L
        </span>
      </div>

      {/* Melting Ice Progress Bar */}
      <div className="relative">
        <div className="h-3 w-full overflow-hidden rounded-full bg-white/[0.04]">
          <div
            className="relative h-full rounded-full transition-all duration-1000"
            style={{
              width: `${progress}%`,
              background: "linear-gradient(90deg, #ff0055, #ff3377, #00f2ea)",
              animation: "melt 4s ease-in-out infinite",
            }}
          >
            {/* Shimmer overlay */}
            <div
              className="absolute inset-0 opacity-40"
              style={{
                background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)",
                backgroundSize: "200% 100%",
                animation: "shimmer 2s linear infinite",
              }}
            />
          </div>
        </div>

        {/* Drip marks for melting effect */}
        <div className="absolute -bottom-1 flex w-full gap-[2px]" style={{ width: `${progress}%` }}>
          {[
            { w: 7.2, ml: 2 },
            { w: 5.8, ml: 8 },
            { w: 9.1, ml: 3.5 },
            { w: 4.4, ml: 10 },
            { w: 6.7, ml: 1.2 },
            { w: 8.3, ml: 6.5 },
            { w: 5.1, ml: 4.8 },
            { w: 7.9, ml: 9.2 },
          ].map((drip, i) => (
            <div
              key={i}
              className="h-1 rounded-full opacity-30"
              style={{
                width: `${drip.w}px`,
                marginLeft: `${drip.ml}%`,
                background: i % 2 === 0 ? "#ff0055" : "#00f2ea",
              }}
            />
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-white/60">
          Debt Free in: <span className="mono-num font-medium text-white/90">4 Years, 2 Months</span>
        </p>
        <span className="mono-num text-xs text-[#00f2ea]">{progress.toFixed(0)}%</span>
      </div>
    </GlassCard>
  )
}
