"use client"

import React, { createContext, useContext, useState, type ReactNode } from "react"

export interface FinancialData {
  monthlyIncome: number
  monthlyExpenses: number
  currentInvestments: number
  termInsurance: number
  healthInsurance: number
}

const defaultData: FinancialData = {
  monthlyIncome: 50000,
  monthlyExpenses: 20000,
  currentInvestments: 500000,
  termInsurance: 10000000,
  healthInsurance: 1000000,
}

interface FinancialContextType {
  data: FinancialData
  setData: React.Dispatch<React.SetStateAction<FinancialData>>
  hasOnboarded: boolean
  setHasOnboarded: React.Dispatch<React.SetStateAction<boolean>>
}

const FinancialContext = createContext<FinancialContextType | null>(null)

export function FinancialProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<FinancialData>(defaultData)
  const [hasOnboarded, setHasOnboarded] = useState(false)

  return (
    <FinancialContext.Provider value={{ data, setData, hasOnboarded, setHasOnboarded }}>
      {children}
    </FinancialContext.Provider>
  )
}

export function useFinancialData() {
  const ctx = useContext(FinancialContext)
  if (!ctx) throw new Error("useFinancialData must be used within FinancialProvider")
  return ctx
}
