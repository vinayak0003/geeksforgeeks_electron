"use client"

import { GlassCard } from "@/components/glass-card"
import { User, Bell, Shield, CreditCard } from "lucide-react"
import { useState } from "react"

const toggleDefaults = [
  { label: "Portfolio Alerts", description: "Significant portfolio changes", enabled: true },
  { label: "Market News", description: "Daily summary and breaking news", enabled: true },
  { label: "Trade Confirmations", description: "Confirmation for every trade", enabled: false },
  { label: "Weekly Report", description: "Comprehensive weekly digest", enabled: true },
]

export default function SettingsPage() {
  const [toggles, setToggles] = useState(toggleDefaults)

  function handleToggle(i: number) {
    setToggles((prev) =>
      prev.map((t, idx) => (idx === i ? { ...t, enabled: !t.enabled } : t))
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-platinum text-2xl font-light tracking-tight">Settings</h1>
        <p className="text-xs text-white/30">Manage your account and preferences.</p>
      </div>

      {/* Profile */}
      <GlassCard>
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#00f2ea]/10">
            <User className="h-4 w-4 text-[#00f2ea]" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm text-white/80">Profile</h3>
            <p className="text-[11px] text-white/30">Manage your personal information</p>
          </div>
        </div>
        <div className="flex flex-col gap-5">
          {[
            { label: "Full Name", value: "Arjun Kapoor", type: "text" },
            { label: "Email", value: "arjun@chronowealth.com", type: "email" },
            { label: "Phone", value: "+91 98765 43210", type: "tel" },
          ].map((field) => (
            <div key={field.label} className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase tracking-[0.12em] text-white/30">{field.label}</label>
              <input
                type={field.type}
                defaultValue={field.value}
                className="glow-input w-full bg-transparent py-2 text-sm text-white/80 placeholder-white/15"
              />
            </div>
          ))}
          <button
            type="button"
            className="mt-2 w-fit rounded-lg bg-[#00f2ea]/10 px-6 py-2.5 text-[10px] uppercase tracking-[0.1em] text-[#00f2ea] ring-1 ring-[#00f2ea]/20 transition-all hover:bg-[#00f2ea]/20"
          >
            Save Changes
          </button>
        </div>
      </GlassCard>

      {/* Notifications */}
      <GlassCard>
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3b82ff]/10">
            <Bell className="h-4 w-4 text-[#3b82ff]" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm text-white/80">Notifications</h3>
            <p className="text-[11px] text-white/30">Configure alerts and updates</p>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          {toggles.map((toggle, i) => (
            <div key={toggle.label} className="flex items-center justify-between border-b border-white/[0.04] pb-4 last:border-0 last:pb-0">
              <div className="flex flex-col gap-0.5">
                <span className="text-sm text-white/70">{toggle.label}</span>
                <span className="text-[11px] text-white/25">{toggle.description}</span>
              </div>
              <button
                type="button"
                onClick={() => handleToggle(i)}
                className={`relative h-5 w-9 rounded-full transition-colors ${
                  toggle.enabled ? "bg-[#00f2ea]/30" : "bg-white/[0.06]"
                }`}
                aria-label={`Toggle ${toggle.label}`}
              >
                <div
                  className={`absolute top-0.5 h-4 w-4 rounded-full transition-all ${
                    toggle.enabled ? "left-[18px] bg-[#00f2ea]" : "left-0.5 bg-white/30"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Security */}
      <GlassCard>
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#ff0055]/10">
            <Shield className="h-4 w-4 text-[#ff0055]" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm text-white/80">Security</h3>
            <p className="text-[11px] text-white/30">Protect your account</p>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          {[
            { label: "Two-Factor Auth", status: "Enabled", action: "Configure" },
            { label: "Login History", status: "Last: 2 hours ago", action: "View All" },
            { label: "API Keys", status: "2 active keys", action: "Manage" },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between border-b border-white/[0.04] pb-4 last:border-0 last:pb-0">
              <div className="flex flex-col gap-0.5">
                <span className="text-sm text-white/70">{item.label}</span>
                <span className="text-[11px] text-white/25">{item.status}</span>
              </div>
              <button
                type="button"
                className="rounded-md border border-white/[0.06] bg-transparent px-3 py-1.5 text-[10px] uppercase tracking-wider text-white/40 transition-all hover:border-white/10 hover:text-white/60"
              >
                {item.action}
              </button>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Billing */}
      <GlassCard>
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-yellow-500/10">
            <CreditCard className="h-4 w-4 text-yellow-500" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm text-white/80">Billing</h3>
            <p className="text-[11px] text-white/30">Subscription and payments</p>
          </div>
        </div>
        <div className="flex items-center justify-between rounded-lg bg-white/[0.02] p-5 ring-1 ring-white/5">
          <div className="flex flex-col gap-1">
            <span className="text-sm font-medium text-white/80">ChronoWealth X Elite</span>
            <span className="text-[11px] text-white/25">Next billing: March 15, 2026</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="mono-num text-lg font-light text-white/80">{"\u20B9"}2,499/mo</span>
            <button
              type="button"
              className="rounded-md border border-white/[0.06] bg-transparent px-3 py-1.5 text-[10px] uppercase tracking-wider text-white/40 transition-all hover:border-white/10 hover:text-white/60"
            >
              Manage
            </button>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}
