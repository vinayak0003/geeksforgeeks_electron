"use client"

import { GlassCard } from "@/components/glass-card"
import { RiverOfWealth } from "@/components/river-of-wealth"
import { FutureDiary } from "@/components/future-diary"
import { Clock, CalendarDays, FastForward } from "lucide-react"

const scenarios = [
  { label: "Conservative", cagr: "10%", corpus: "\u20B94.2 Cr", color: "#3b82ff" },
  { label: "Moderate", cagr: "14%", corpus: "\u20B97.8 Cr", color: "#00f2ea" },
  { label: "Aggressive", cagr: "18%", corpus: "\u20B912.5 Cr", color: "#ff0055" },
]

export default function TimeTravelPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-platinum text-2xl font-light tracking-tight">Time Travel</h1>
        <p className="text-xs text-white/30">Project your wealth across different timelines and scenarios.</p>
      </div>

      {/* Scenario Cards */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        {scenarios.map((s) => (
          <GlassCard key={s.label} className="flex flex-col gap-3 p-5">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
              <span className="heading-luxury text-[10px] uppercase tracking-[0.15em] text-white/40">{s.label}</span>
            </div>
            <div className="flex items-end gap-3">
              <span className="mono-num text-xl font-light text-white/90">{s.corpus}</span>
              <span className="mono-num mb-0.5 text-[10px]" style={{ color: s.color }}>CAGR {s.cagr}</span>
            </div>
            <p className="text-[10px] text-white/25">Projected corpus by 2050</p>
          </GlassCard>
        ))}
      </div>

      {/* Main Chart + Timeline */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <RiverOfWealth />
        </div>
        <FutureDiary />
      </div>

      {/* Quick Controls */}
      <GlassCard>
        <h3 className="heading-luxury mb-4 text-xs uppercase tracking-[0.15em] text-white/40">Timeline Controls</h3>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <div className="flex items-center gap-3 rounded-lg bg-white/[0.02] p-4 ring-1 ring-white/5">
            <Clock className="h-4 w-4 text-[#00f2ea]" strokeWidth={1.5} />
            <div>
              <span className="text-xs text-white/60">Start Year</span>
              <p className="mono-num text-sm text-white/90">2024</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg bg-white/[0.02] p-4 ring-1 ring-white/5">
            <CalendarDays className="h-4 w-4 text-[#3b82ff]" strokeWidth={1.5} />
            <div>
              <span className="text-xs text-white/60">Target Year</span>
              <p className="mono-num text-sm text-white/90">2050</p>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg bg-white/[0.02] p-4 ring-1 ring-white/5">
            <FastForward className="h-4 w-4 text-[#ff0055]" strokeWidth={1.5} />
            <div>
              <span className="text-xs text-white/60">Inflation Assumed</span>
              <p className="mono-num text-sm text-white/90">5.6%</p>
            </div>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}
