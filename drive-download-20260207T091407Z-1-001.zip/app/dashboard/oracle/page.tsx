"use client"

import { GlassCard } from "@/components/glass-card"
import { Sparkles, Brain, TrendingUp, Shield } from "lucide-react"

const insights = [
  {
    title: "Retirement Optimization",
    summary: "Increasing your SIP by \u20B915K/month could advance your \u20B95 Cr goal by 3 years.",
    icon: TrendingUp,
    color: "#00f2ea",
    priority: "High",
  },
  {
    title: "Tax Harvesting Alert",
    summary: "You have \u20B980K in unrealized short-term losses. Consider harvesting before March 31.",
    icon: Brain,
    color: "#3b82ff",
    priority: "Medium",
  },
  {
    title: "Insurance Gap Detected",
    summary: "Your term cover of \u20B91 Cr may be insufficient. Recommended: \u20B92.5 Cr based on liabilities.",
    icon: Shield,
    color: "#ff0055",
    priority: "High",
  },
  {
    title: "Gold Rebalancing",
    summary: "Gold is 18% of portfolio vs 10% target. Consider trimming \u20B93.2L and moving to equity.",
    icon: Sparkles,
    color: "#eab308",
    priority: "Low",
  },
]

export default function OraclePage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-3">
          <h1 className="text-platinum text-2xl font-light tracking-tight">AI Oracle</h1>
          <div className="flex items-center gap-1.5 rounded-full bg-[#00f2ea]/10 px-2.5 py-1 ring-1 ring-[#00f2ea]/20">
            <div className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#00f2ea]" />
            <span className="text-[9px] uppercase tracking-wider text-[#00f2ea]">Live</span>
          </div>
        </div>
        <p className="text-xs text-white/30">AI-powered insights tailored to your financial profile.</p>
      </div>

      {/* Insights */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {insights.map((item) => (
          <GlassCard key={item.title} className="flex flex-col gap-4 p-5">
            <div className="flex items-start justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ backgroundColor: `${item.color}10` }}>
                <item.icon className="h-4 w-4" style={{ color: item.color }} strokeWidth={1.5} />
              </div>
              <span
                className="rounded-full px-2 py-0.5 text-[9px] uppercase tracking-wider ring-1"
                style={{
                  color: item.color,
                  backgroundColor: `${item.color}10`,
                  boxShadow: `inset 0 0 0 1px ${item.color}25`,
                }}
              >
                {item.priority}
              </span>
            </div>
            <div>
              <h4 className="text-sm text-white/80">{item.title}</h4>
              <p className="mt-1.5 text-[12px] leading-relaxed text-white/40">{item.summary}</p>
            </div>
            <button
              type="button"
              className="w-fit rounded-lg px-4 py-2 text-[10px] uppercase tracking-[0.1em] transition-all hover:bg-white/5"
              style={{ color: item.color, border: `1px solid ${item.color}25` }}
            >
              Explore
            </button>
          </GlassCard>
        ))}
      </div>

      {/* Summary */}
      <GlassCard>
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#00f2ea]/10 ring-1 ring-[#00f2ea]/20">
            <Sparkles className="h-3.5 w-3.5 text-[#00f2ea]" strokeWidth={1.5} />
          </div>
          <h3 className="heading-luxury text-xs uppercase tracking-[0.15em] text-white/40">Oracle Summary</h3>
        </div>
        <p className="text-sm leading-relaxed text-white/50">
          Based on your current trajectory, you are on track to achieve financial independence by age 52.
          Your portfolio has a healthy Sharpe ratio of 1.6, but your debt-to-income ratio of 28% could be
          optimized. The Oracle recommends focusing on the high-priority items above to maximize your
          wealth accumulation by <span className="mono-num text-[#00f2ea]">{"\u20B9"}2.8 Cr</span> over the next decade.
        </p>
      </GlassCard>
    </div>
  )
}
