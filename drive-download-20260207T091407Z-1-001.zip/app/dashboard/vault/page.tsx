"use client"

import { KnowledgeVault } from "@/components/knowledge-vault"
import { GlassCard } from "@/components/glass-card"
import { Shield, BookOpen, FileText, Scale } from "lucide-react"

const resources = [
  { title: "Section 80C Guide", desc: "Max deductions up to \u20B91.5L under 80C, 80CCC, 80CCD", icon: FileText, tag: "Tax" },
  { title: "NPS Tier-I Benefits", desc: "Extra \u20B950K deduction under 80CCD(1B)", icon: Shield, tag: "Retirement" },
  { title: "LTCG Tax Rules 2024", desc: "12.5% on gains above \u20B91.25L for equity", icon: Scale, tag: "Capital Gains" },
  { title: "HRA Exemption Calc", desc: "Claim HRA if living in a rented house", icon: BookOpen, tag: "Salary" },
]

export default function VaultPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-platinum text-2xl font-light tracking-tight">Knowledge Vault</h1>
        <p className="text-xs text-white/30">Indian tax laws, gold insights, and market intelligence.</p>
      </div>

      {/* Knowledge Vault Cards */}
      <KnowledgeVault />

      {/* Resources */}
      <div className="flex flex-col gap-4">
        <h3 className="heading-luxury text-xs uppercase tracking-[0.15em] text-white/40">Tax Resources</h3>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {resources.map((r) => (
            <GlassCard key={r.title} className="flex items-start gap-4 p-5">
              <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-[#00f2ea]/[0.06] ring-1 ring-[#00f2ea]/10">
                <r.icon className="h-4 w-4 text-[#00f2ea]/70" strokeWidth={1.5} />
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-white/80">{r.title}</span>
                  <span className="rounded bg-white/[0.04] px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-white/30 ring-1 ring-white/[0.06]">{r.tag}</span>
                </div>
                <p className="text-[11px] text-white/30">{r.desc}</p>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  )
}
