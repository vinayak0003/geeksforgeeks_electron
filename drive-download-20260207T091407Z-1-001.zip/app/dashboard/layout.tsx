"use client"

import type { ReactNode } from "react"
import { Sidebar } from "@/components/sidebar"
import { AnimatedBackground } from "@/components/animated-background"
import { useMousePosition } from "@/hooks/use-mouse-position"
import { motion } from "framer-motion"

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const mouse = useMousePosition()

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="relative min-h-screen"
      style={{
        background: `radial-gradient(600px circle at ${mouse.x}px ${mouse.y}px, rgba(255,255,255,0.06), transparent 40%), #050505`,
      }}
    >
      <AnimatedBackground />
      <Sidebar />
      <main className="ml-[72px] min-h-screen p-6 lg:p-8">{children}</main>
    </motion.div>
  )
}
