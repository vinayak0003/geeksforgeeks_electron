"use client"

import React from "react"
import { RiverOfWealth } from "@/components/river-of-wealth"
import { FutureDiary } from "@/components/future-diary"
import { KnowledgeVault } from "@/components/knowledge-vault"
import { AIOracle } from "@/components/ai-oracle"
import { DebtDestroyer } from "@/components/debt-destroyer"
import { GlassCard } from "@/components/glass-card"
import { useFinancialData } from "@/lib/financial-context"
import { motion } from "framer-motion"
import { TrendingUp, Wallet, Target, Zap } from "lucide-react"

function formatINR(val: number) {
  if (val >= 10000000) return `${(val / 10000000).toFixed(1)} Cr`
  if (val >= 100000) return `${(val / 100000).toFixed(1)}L`
  if (val >= 1000) return `${(val / 1000).toFixed(0)}K`
  return val.toString()
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
}

const item = {
  hidden: { opacity: 0, y: 16, filter: "blur(10px)" },
  show: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.5 } },
}

export default function DashboardPage() {
  const { data } = useFinancialData()

  const savings = Math.max(0, data.monthlyIncome - data.monthlyExpenses)
  const annualSavings = savings * 12
  const projectedWealth5y = data.currentInvestments + annualSavings * 5 * 1.1

  const statCards = [
    {
      label: "Net Worth",
      value: `\u20B9${formatINR(data.currentInvestments)}`,
      change: `+${formatINR(savings)}/mo`,
      icon: Wallet,
      color: "#00f2ea",
    },
    {
      label: "Monthly SIP",
      value: `\u20B9${formatINR(savings)}`,
      change: "Active",
      icon: TrendingUp,
      color: "#00f2ea",
    },
    {
      label: "5Y Projection",
      value: `\u20B9${formatINR(projectedWealth5y)}`,
      change: "On Track",
      icon: Target,
      color: "#3b82ff",
    },
    {
      label: "Risk Score",
      value: "6.4/10",
      change: "Moderate",
      icon: Zap,
      color: "#ff0055",
    },
  ]

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="flex flex-col gap-6"
    >
      {/* Header */}
      <motion.div variants={item} className="flex flex-col gap-1">
        <h1 className="text-platinum text-2xl font-light tracking-tight">
          Welcome back, Arjun
        </h1>
        <p className="text-xs text-white/30">
          Savings of {"\u20B9"}{formatINR(savings)}/month projected over the next decade.
        </p>
      </motion.div>

      {/* Stat Cards */}
      <motion.div variants={item} className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {statCards.map((stat) => (
          <GlassCard key={stat.label} className="flex flex-col gap-3 p-4">
            <div className="flex items-center justify-between">
              <span className="heading-luxury text-[10px] uppercase tracking-[0.15em] text-white/35">
                {stat.label}
              </span>
              <stat.icon
                className="h-3.5 w-3.5"
                style={{ color: stat.color }}
                strokeWidth={1.5}
              />
            </div>
            <div className="flex items-end gap-2">
              <span className="mono-num text-xl font-light text-white/90">{stat.value}</span>
              <span className="mb-0.5 text-[10px]" style={{ color: stat.color }}>
                {stat.change}
              </span>
            </div>
          </GlassCard>
        ))}
      </motion.div>

      {/* River of Wealth + Future Diary */}
      <motion.div variants={item} className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <RiverOfWealth />
        </div>
        <FutureDiary />
      </motion.div>

      {/* Knowledge Vault */}
      <motion.div variants={item}>
        <KnowledgeVault />
      </motion.div>

      {/* Debt Destroyer */}
      <motion.div variants={item}>
        <DebtDestroyer />
      </motion.div>

      {/* AI Oracle FAB */}
      <AIOracle />
    </motion.div>
  )
}
