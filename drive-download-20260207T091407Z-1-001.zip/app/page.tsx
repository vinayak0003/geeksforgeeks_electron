"use client"

import React, { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { AnimatedBackground } from "@/components/animated-background"
import { useFinancialData } from "@/lib/financial-context"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles } from "lucide-react"

function formatINR(val: number) {
  if (val >= 10000000) return `${(val / 10000000).toFixed(1)} Cr`
  if (val >= 100000) return `${(val / 100000).toFixed(1)}L`
  if (val >= 1000) return `${(val / 1000).toFixed(0)}K`
  return val.toString()
}

function TypewriterText({ text, className }: { text: string; className?: string }) {
  const [displayed, setDisplayed] = useState("")
  const [index, setIndex] = useState(0)

  useEffect(() => {
    if (index < text.length) {
      const timer = setTimeout(() => {
        setDisplayed((prev) => prev + text[index])
        setIndex((prev) => prev + 1)
      }, 45)
      return () => clearTimeout(timer)
    }
  }, [index, text])

  return (
    <span className={className}>
      {displayed}
      {index < text.length && (
        <span
          className="inline-block w-[2px] h-[1.1em] bg-[#00f2ea] align-text-bottom ml-0.5"
          style={{ animation: "blink-caret 0.8s step-end infinite" }}
        />
      )}
    </span>
  )
}

interface SliderFieldProps {
  label: string
  value: number
  min: number
  max: number
  step: number
  onChange: (val: number) => void
}

function SliderField({ label, value, min, max, step, onChange }: SliderFieldProps) {
  const pct = ((value - min) / (max - min)) * 100

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <label className="text-[10px] uppercase tracking-[0.15em] text-white/30">
          {label}
        </label>
      </div>
      <div className="relative pt-6 pb-1">
        {/* Floating value above thumb */}
        <div
          className="absolute top-0 -translate-x-1/2 pointer-events-none"
          style={{ left: `calc(${pct}% + ${(0.5 - pct / 100) * 20}px)` }}
        >
          <span className="mono-num rounded-md bg-[#00f2ea]/10 px-2 py-0.5 text-xs font-medium text-[#00f2ea] ring-1 ring-[#00f2ea]/25 shadow-[0_0_12px_rgba(0,242,234,0.3)]">
            {"\u20B9"}{formatINR(value)}
          </span>
        </div>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="luxury-slider w-full"
        />
      </div>
    </div>
  )
}

interface NumberFieldProps {
  label: string
  value: number
  onChange: (val: number) => void
  placeholder?: string
}

function NumberField({ label, value, onChange, placeholder }: NumberFieldProps) {
  return (
    <div className="flex flex-col gap-2">
      <label className="text-[10px] uppercase tracking-[0.15em] text-white/30">
        {label}
      </label>
      <div className="relative">
        <span className="absolute left-0 top-1/2 -translate-y-1/2 text-sm text-white/20">{"\u20B9"}</span>
        <input
          type="number"
          value={value || ""}
          onChange={(e) => onChange(Number(e.target.value) || 0)}
          placeholder={placeholder}
          className="glow-input mono-num w-full bg-transparent py-2.5 pl-4 text-sm text-white/80 placeholder-white/15 focus:outline-none"
        />
      </div>
    </div>
  )
}

export default function SanctuaryPage() {
  const { data, setData, setHasOnboarded } = useFinancialData()
  const [exiting, setExiting] = useState(false)
  const router = useRouter()

  const handleChange = useCallback(
    (field: keyof typeof data) => (val: number) => {
      setData((prev) => ({ ...prev, [field]: val }))
    },
    [setData]
  )

  function handleAnalyze() {
    setExiting(true)
    setHasOnboarded(true)
    setTimeout(() => {
      router.push("/dashboard")
    }, 600)
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden">
      <AnimatedBackground />

      <AnimatePresence>
        {!exiting && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: -30 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="glass-highlight glass-spotlight relative z-10 mx-4 w-full max-w-[520px] overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.03] p-8 md:p-10"
            style={{
              backdropFilter: "blur(40px)",
              WebkitBackdropFilter: "blur(40px)",
            }}
          >
            {/* Header */}
            <div className="mb-8 flex flex-col items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#00f2ea]/10 ring-1 ring-[#00f2ea]/20">
                <Sparkles className="h-6 w-6 text-[#00f2ea]" strokeWidth={1.5} />
              </div>
              <div className="flex flex-col items-center gap-2 text-center">
                <h1 className="text-platinum text-lg font-light tracking-[0.08em]">
                  <TypewriterText text="Welcome to your Financial Digital Twin" />
                </h1>
                <p className="animate-unblur text-[11px] text-white/25" style={{ animationDelay: "2s" }}>
                  The Sanctuary analyses your financial DNA
                </p>
              </div>
            </div>

            {/* Form */}
            <div className="flex flex-col gap-6">
              <SliderField
                label="Monthly Income"
                value={data.monthlyIncome}
                min={10000}
                max={1000000}
                step={5000}
                onChange={handleChange("monthlyIncome")}
              />

              <SliderField
                label="Monthly Expenses"
                value={data.monthlyExpenses}
                min={5000}
                max={500000}
                step={5000}
                onChange={handleChange("monthlyExpenses")}
              />

              <div className="h-px bg-white/[0.04]" />

              <NumberField
                label="Current Investments"
                value={data.currentInvestments}
                onChange={handleChange("currentInvestments")}
                placeholder="5,00,000"
              />

              <div className="grid grid-cols-2 gap-4">
                <NumberField
                  label="Term Insurance"
                  value={data.termInsurance}
                  onChange={handleChange("termInsurance")}
                  placeholder="1,00,00,000"
                />
                <NumberField
                  label="Health Insurance"
                  value={data.healthInsurance}
                  onChange={handleChange("healthInsurance")}
                  placeholder="10,00,000"
                />
              </div>

              {/* Savings Preview */}
              <div className="flex items-center justify-between rounded-xl bg-white/[0.02] p-4 ring-1 ring-white/[0.05]">
                <span className="text-[10px] uppercase tracking-[0.12em] text-white/30">
                  Monthly Savings
                </span>
                <span className="mono-num text-lg font-light text-[#00f2ea]">
                  {"\u20B9"}{formatINR(Math.max(0, data.monthlyIncome - data.monthlyExpenses))}
                </span>
              </div>

              {/* CTA */}
              <motion.button
                onClick={handleAnalyze}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group relative w-full overflow-hidden rounded-xl bg-[#00f2ea]/10 py-4 text-xs font-medium uppercase tracking-[0.2em] text-[#00f2ea] ring-1 ring-[#00f2ea]/20 transition-all duration-300 hover:bg-[#00f2ea]/20 hover:ring-[#00f2ea]/40 hover:shadow-[0_0_40px_rgba(0,242,234,0.15)]"
              >
                <span className="relative z-10">Analyze Future</span>
              </motion.button>
            </div>

            {/* Footer */}
            <p className="mt-6 text-center text-[9px] text-white/15">
              All data stays on your device. Zero tracking.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
